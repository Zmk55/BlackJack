BlackJack SSH Client - Windows Build
====================================

Version: 1.0.0
Build Date: 10/06/2025 08:49:58

Quick Start:
1. Double-click start-blackjack.bat to start the server
2. Open your browser and go to http://localhost:8082
3. Use the web interface to manage your SSH connections

Files:
- blackjack-server.exe: Main server executable
- web-app/: Web interface files
- start-blackjack.bat: Startup script

For more information, visit: https://github.com/Zmk55/BlackJack
